<?php
session_start();

require_once('settings.php');
require_once('google_config_api.php');
?>



<html>
<head>
	
 <style> 
  body
  {
   background-color:#f1f1f1;
  }
  .loginbox  
        {  
   width:500px;
   background-color:#ffffff;
   margin:0 auto;  
    padding:16px;  
    text-align:center;  
    margin-top:50px;
   border:1px solid #ccc;
   border-radius:5px;
        }  
  </style>  


</head>

<body>
	<div class="container loginbox">
	<?php
// Google passes a parameter 'code' in the Redirect Url
if(isset($_GET['code'])) {
	try {
		$gapi = new GoogleLoginApi();
		
		// Get the access token 
		$data = $gapi->GetAccessToken(CLIENT_ID, CLIENT_REDIRECT_URL, CLIENT_SECRET, $_GET['code']);
		
		// Get user information
		$user_info = $gapi->GetUserProfileInfo($data['access_token']);
		//$user_info['emails'][0]['value']

		echo 'Email :-'.$user_info['emails'][0]['value']; echo "<br/>";
		echo 'Display Name :-'.$user_info['displayName']; echo "<br/>";
		echo 'ID :-'.$user_info['id']; echo "<br/>";
		// echo 'phone:-'.$user_info['phone'];echo "<br/>";
		echo 'language :-'.$user_info['language']; echo "<br/>";
		
		echo '<img src="'.$user_info['image']['url'].'" >';
		//echo '<pre>';print_r($user_info); echo '</pre>';
		// Now that the user is logged in you may want to start some session variables
		$_SESSION['logged_in'] = 1;

		// if($user_info['emails'][0]['value']){

			
		// 	if($user_info['emails'][0]['value'] == 'sarojkumar.dalai@gmail.com'){
		// 		 header('Location: dashboard.php');
		// 		 $_SESSION['email'] = $user_info['emails'][0]['value'];
		// 		 exit();

		// 	}
		// }
  echo '<li><a href="./logout.php"><span class="glyphicon glyphicon-log-in"></span>Logout</a></li>';
		// You may now want to redirect the user to the home page of your website
		// header('Location: home.php');
	}
	catch(Exception $e) {
		echo $e->getMessage();
		exit();
	}
}

?>

	
	</div>
</body>
</html>