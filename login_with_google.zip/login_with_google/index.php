<?php

require_once('settings.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Python Mini Projects</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="./assets/js/bootstrap.min.js"></script>
 <!--  <link href='/assets/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
<script src="/assets/js/jquery.dataTables.min.js"></script> -->
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
<script src="./assets/js/jquery.dataTables.min.js"></script>



<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
  <style>


    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .container {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
}
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
      background-color: dodgerblue;
    }
    .navbar-brand {
    float: left;
    height: auto !important;
    padding: 15px 15px;
    font-size: 18px;
    line-height: 20px;
  }
  .navbar-inverse .navbar-nav>li>a {
    color: white;
    font-size: 25px;
  }
  h2{
    padding: 10px;
    border:   1px solid dodgerblue;
    border-left: 5px solid dodgerblue;
  }

    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 450px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      margin-top: 10px;
      background-color: #f1f1f1;
      height: 400px;
    }
     .nav>li {
   
    margin-top: 30px;
  }

    /* Set black background color, white text and some padding */
    footer {
      background-color: dodgerblue;
      color: white;
      padding: 15px;
      margin-top: 10px;
    }
    .carousel{
      margin-top: 10px;
    }
    .my-menu div{
      height: 100px;
      width: 200px;
      background-color: #ccc;
      margin-left: 10px;
    }
    .well{
      margin-left:10px;
      height:   100px;
      width: 200px;
    }
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height:auto;} 
      .nav>li {
   
    margin-top: 2px;
  }
    }
  </style>
</head>


<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="/"><img src="./assets/images/logo.png" alt="image 1" width="200px" height="80px" /></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      
<ul class="nav navbar-nav">
          
                
                 <li class="active"><a href="/" id="home_page" class="current">Home</a></li>
                    <li><a href="/pages/about" id="about_page" >About project</a></li>
                    <li><a href="/pages/contact" id="contact_page">Contact</a></li>
                    
               
            </ul>     

      <ul class="nav navbar-nav navbar-right">
         
          
        <li><a href="/users"><span class="glyphicon glyphicon-log-out"></span> Admin Login</a></li>
        
      </ul>
    </div>
  </div>
</nav>




 
    

  


<div class="container">
  <div class="col-sm-4 text-left" >
<h2>Login to your account </h2>
 <form id="contact_form" action="#" method="POST" enctype="multipart/form-data">
 
    <div class="form-group">
     <label for="name">User Name:</label>
          <input id="username" class="form-control" name="username" type="text" value="" size="30" required/>
    </div>
    <div class="form-group">
      <label for="email">Password:</label>
          <input id="password" class="form-control" name="password" type="password" value="" size="30" required/>
    </div>
   
   
      <button name="submit" type="submit" class="btn btn-default">Sign in</button>
        <div style="margin-top:10px; font-size:14px; font-weight:bold; cursor:pointer; ">Forgot Password ? &nbsp; Click Here</div>
        <hr/>
       
          <a href="<?= 'https://accounts.google.com/o/oauth2/v2/auth?scope=' . urlencode('https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/plus.me') . '&redirect_uri=' . urlencode(CLIENT_REDIRECT_URL) . '&response_type=code&client_id=' . CLIENT_ID . '&access_type=online' ?>"><img src="./assets/images/google-btn.png"></a>
        <input type="hidden" name="act" value="check_login">
  </form>


</div>
  <div class="col-sm-8" >
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="./assets/images/student-1.jpg" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <img src="./assets/images/student-1.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
</div>

    

<!-- end of content wrapper -->

  
<footer class="container-fluid text-center">
  <p>Copyright © 2018 student Information system. All Rights Reserved.</p>
</footer>

</body>
</html>
