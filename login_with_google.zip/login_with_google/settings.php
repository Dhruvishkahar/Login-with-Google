<?php

/* Google App Client Id */
define('CLIENT_ID', '383951569731-6n6d5bhapnq0i7eq6pjn1k966o6h7h42.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', '7C_z2sUZXNe1YUZ5INg2ih1e');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/login_with_google/google_auth.php');

?>
		
